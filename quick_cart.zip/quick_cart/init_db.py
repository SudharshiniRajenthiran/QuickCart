
from app import create_app, db
from models import User, Product, Order, OrderItem, HashTable
from database import init_db

if __name__ == "__main__":
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Initialize database with sample data
        init_db()
        
        print("Database initialized successfully!")
