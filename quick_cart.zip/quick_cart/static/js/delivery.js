// Delivery dashboard functionality for QuickCart

document.addEventListener('DOMContentLoaded', function() {
    // Function to attach event listener to status buttons
    function attachStatusButtonListener(button) {
        button.addEventListener('click', function() {
            const orderId = this.getAttribute('data-order-id');
            const newStatus = this.getAttribute('data-status');
            
            const formData = new FormData();
            formData.append('order_id', orderId);
            formData.append('status', newStatus);
            
            // Get CSRF token from meta tag
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            formData.append('csrf_token', csrfToken);
            
            fetch('/delivery/update_order_status', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success toast
                    const toast = new bootstrap.Toast(document.getElementById('statusToast'));
                    document.getElementById('statusToastBody').textContent = data.message;
                    toast.show();
                    
                    // Update UI
                    const orderCard = document.getElementById(`order-${orderId}`);
                    
                    if (orderCard) {
                        // Update status badge
                        const statusBadge = orderCard.querySelector('.order-status');
                        if (statusBadge) {
                            // Remove old status classes
                            statusBadge.classList.remove('status-pending', 'status-processing', 'status-shipped', 'status-delivered');
                            // Add new status class
                            statusBadge.classList.add(`status-${newStatus}`);
                            statusBadge.textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
                        }
                        
                        // Move card to appropriate section
                        const currentSection = orderCard.parentNode;
                        let targetSection;
                        
                        if (newStatus === 'processing') {
                            targetSection = document.getElementById('processing-orders-container');
                        } else if (newStatus === 'shipped') {
                            // For shipped orders, update the button to "Mark as Delivered"
                            const actionCell = orderCard.querySelector('td:last-child');
                            if (actionCell) {
                                actionCell.innerHTML = `
                                    <button class="btn btn-sm btn-primary update-status-btn" 
                                            data-order-id="${orderId}" 
                                            data-status="delivered">
                                        <i class="fas fa-check-circle me-1"></i> Mark Delivered
                                    </button>
                                `;
                                // Re-attach event listener to the new button
                                const newButton = actionCell.querySelector('.update-status-btn');
                                if (newButton) {
                                    attachStatusButtonListener(newButton);
                                }
                            }
                        } else if (newStatus === 'delivered') {
                            // For delivered orders, remove the button
                            const actionCell = orderCard.querySelector('td:last-child');
                            if (actionCell) {
                                actionCell.innerHTML = `
                                    <span class="badge bg-success">
                                        <i class="fas fa-check me-1"></i> Delivered
                                    </span>
                                `;
                            }
                        }
                        
                        if (targetSection && currentSection !== targetSection) {
                            currentSection.removeChild(orderCard);
                            targetSection.appendChild(orderCard);
                            
                            // Update buttons based on new status
                            const buttonContainer = orderCard.querySelector('.order-actions');
                            if (buttonContainer) {
                                if (newStatus === 'processing') {
                                    buttonContainer.innerHTML = `
                                        <button class="btn btn-sm btn-success update-status-btn" 
                                                data-order-id="${orderId}" 
                                                data-status="shipped">
                                            Mark as Shipped
                                        </button>
                                    `;
                                }
                            }
                        }
                    }
                } else {
                    console.error('Error updating status:', data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    };
    
    // Attach event listeners to all status buttons
    const statusButtons = document.querySelectorAll('.update-status-btn');
    statusButtons.forEach(button => {
        attachStatusButtonListener(button);
    });
});
    
 // Order priority visualization